import ctypes
import time
import os
import sys
import random
from PIL import ImageGrab
import cv2
import numpy as np
import pydirectinput  # <-- Biblioteca mais segura para jogos DirectX

# Desativar o fail-safe do pydirectinput para evitar travamentos no meio do jogo
pydirectinput.FAILSAFE = False

# =======================================================================
# --- Configurações Iniciais e APIs do Windows ---
# =======================================================================
VK_F6 = 0x75   # ALTERNAR (ATIVAR / DESATIVAR)
VK_F7 = 0x76   # SAIR
VK_Z  = 0x5A   # PAUSAR
VK_F12 = 0x7B

TARGET_B = 0
TARGET_G = 0
TARGET_R = 255
VARIATION = 0      
SEARCH_RADIUS = 250  

def obter_estado_tecla(vkey):
    return (ctypes.windll.user32.GetAsyncKeyState(vkey) & 0x8000) != 0

def delay_humano(mu, sigma):
    """
    Gera um delay baseado em uma distribuição normal (Curva de Gauss).
    """
    delay = random.gauss(mu, sigma)
    return max(mu - (2 * sigma), min(delay, mu + (2 * sigma)))

def enviar_clique_humanizado():
    pydirectinput.mouseDown(button='left')
    # Otimizado: Reduzido para ~12ms a 18ms (Ainda registra perfeitamente no jogo)
    time.sleep(delay_humano(0.015, 0.002)) 
    pydirectinput.mouseUp(button='left')

# (A função ciclo_troca_arma_humanizado foi totalmente removida daqui)

# Dimensões dinâmicas da tela principal
largura_tela = ctypes.windll.user32.GetSystemMetrics(0)
altura_tela = ctypes.windll.user32.GetSystemMetrics(1)
mid_x = largura_tela // 2
mid_y = altura_tela // 2

bbox = (
    mid_x - SEARCH_RADIUS,
    mid_y - SEARCH_RADIUS,
    mid_x + SEARCH_RADIUS,
    mid_y + SEARCH_RADIUS
)

aimbot_ativo = False
script_suspenso = False

os.system('cls' if os.name == 'nt' else 'clear')
print("==================================================")
print(" [F6] ATIVAR/DESATIVAR | [Z] PAUSAR | [F7] SAIR")
print("==================================================")
print("STATUS: AGUARDANDO ATIVAÇÃO (MODO - CLIQUE - NORMAL)")

# =======================================================================
# --- Loop Principal ---
# =======================================================================
try:
    while True:
        if obter_estado_tecla(VK_F12):
            # Simula pressionar Win + D usando ctypes
            ctypes.windll.user32.keybd_event(0x5B, 0, 0, 0)  # Tecla Windows (VK_LWIN)
            ctypes.windll.user32.keybd_event(0x44, 0, 0, 0)  # Tecla D
            ctypes.windll.user32.keybd_event(0x44, 0, 2, 0)  # Solta D
            ctypes.windll.user32.keybd_event(0x5B, 0, 2, 0)  # Solta Windows
            
            print("\033[93m🖥️ Minimizado para a Área de Trabalho\033[0m")
            time.sleep(0.4)  

        if obter_estado_tecla(VK_F7):
            print("Encerrando execução...")
            break

        if not script_suspenso:
            if obter_estado_tecla(VK_F6):
                aimbot_ativo = not aimbot_ativo  
                if aimbot_ativo:
                    print("\033[92m🎯 MONITORAÇÃO: ATIVA\033[0m")
                else:
                    print("\033[93m⚡ MONITORAÇÃO: OFF\033[0m")
                time.sleep(0.4)  

            if aimbot_ativo:
                screenshot = ImageGrab.grab(bbox=bbox)
                frame = np.array(screenshot)
                frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

                limite_inferior = np.array([
                    max(0, TARGET_B - VARIATION),
                    max(0, TARGET_G - VARIATION),
                    max(0, TARGET_R - VARIATION)
                ])
                limite_superior = np.array([
                    min(255, TARGET_B + VARIATION),
                    min(255, TARGET_G + VARIATION),
                    min(255, TARGET_R + VARIATION)
                ])

                mascara = cv2.inRange(frame_bgr, limite_inferior, limite_superior)

                if np.any(mascara == 255):
                    if ctypes.windll.user32.GetForegroundWindow() != 0:
                        # Tempo de reação ultra-rápido (~3ms)
                        time.sleep(delay_humano(0.003, 0.001))
                        
                        quantidade_tiros = 3 
                        
                        for _ in range(quantidade_tiros):
                            enviar_clique_humanizado()
                            # Intervalo curtíssimo entre os tiros (~5ms)
                            time.sleep(delay_humano(0.005, 0.001))
                        
                        # Cooldown final bem curto para engatar a próxima ação (~30ms)
                        time.sleep(delay_humano(0.030, 0.005))

        time.sleep(0.001)

except KeyboardInterrupt:
    print("\nExecução interrompida manualmente.")
finally:
    print("Script finalizado.")
    input("Pressione Enter para fechar esta janela...")