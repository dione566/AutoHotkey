@echo off
title Iniciando o Servidor Python
echo Instalando dependencias caso nao existam...
pip install keyboard pillow opencv-python pydirectinput

echo.
echo Iniciando o script...
python "%~dp0Click_PB.py"
pause