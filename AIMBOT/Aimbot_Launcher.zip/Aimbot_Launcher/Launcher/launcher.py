import ctypes
import os
import random
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox
import cv2
import numpy as np
import pydirectinput
from PIL import ImageGrab

# Desativar o fail-safe do pydirectinput para evitar travamentos no meio do jogo
pydirectinput.FAILSAFE = False

# =======================================================================
# --- Configurações Comuns e APIs do Windows (Atalhos Atualizados) ---
# =======================================================================
VK_F9  = 0x78   # EMERGÊNCIA / PARAR TUDO
VK_F10 = 0x79   # FECHAR SCRIPT POR COMPLETO (ENCERRAR PROCESSO)
VK_F5  = 0x74   # ATIVAR MODO CLICK (NORMAL)
VK_F6  = 0x75   # ATIVAR MODO SNIPER (TROCA)
VK_Z   = 0x5A   # PAUSAR
VK_F12 = 0x7B   # MINIMIZAR

TARGET_B = 0
TARGET_G = 0
TARGET_R = 255
VARIATION = 0      
SEARCH_RADIUS = 250  

def obter_estado_tecla(vkey):
    return (ctypes.windll.user32.GetAsyncKeyState(vkey) & 0x8000) != 0

def delay_humano(mu, sigma):
    delay = random.gauss(mu, sigma)
    return max(mu - (2 * sigma), min(delay, mu + (2 * sigma)))

def enviar_clique_humanizado():
    pydirectinput.mouseDown(button='left')
    time.sleep(delay_humano(0.015, 0.002)) 
    pydirectinput.mouseUp(button='left')

# =======================================================================
# --- Lógica do Script 1: Click_PB ---
# =======================================================================
def rodar_click_pb(parar_evento):
    largura_tela = ctypes.windll.user32.GetSystemMetrics(0)
    altura_tela = ctypes.windll.user32.GetSystemMetrics(1)
    mid_x = largura_tela // 2
    mid_y = altura_tela // 2

    bbox = (
        mid_x - SEARCH_RADIUS,
        mid_y - SEARCH_RADIUS,
        mid_x + SEARCH_RADIUS,
        mid_y + SEARCH_RADIUS
    )

    aimbot_ativo = True  
    script_suspenso = False

    print("==================================================")
    print(" [F10] FECHAR TUDO | [F9] PARAR | [Z] PAUSAR")
    print("==================================================")
    print("STATUS: MONITORAÇÃO JÁ INICIADA (MODO - CLIQUE - NORMAL)")

    try:
        while not parar_evento.is_set():
            if obter_estado_tecla(VK_F12):
                ctypes.windll.user32.keybd_event(0x5B, 0, 0, 0)
                ctypes.windll.user32.keybd_event(0x44, 0, 0, 0)
                ctypes.windll.user32.keybd_event(0x44, 0, 2, 0)
                ctypes.windll.user32.keybd_event(0x5B, 0, 2, 0)
                print("\033[93m🖥️ Minimizado para a Área de Trabalho\033[0m")
                time.sleep(0.4)  

            if obter_estado_tecla(VK_Z):
                script_suspenso = not script_suspenso
                if script_suspenso:
                    print("\033[91m⏸️ SCRIPT PAUSADO (Z)\033[0m")
                else:
                    print("\033[92m▶️ SCRIPT RETOMADO (Z)\033[0m")
                time.sleep(0.4)

            if not script_suspenso and aimbot_ativo:
                screenshot = ImageGrab.grab(bbox=bbox)
                frame = np.array(screenshot)
                frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

                limite_inferior = np.array([max(0, TARGET_B - VARIATION), max(0, TARGET_G - VARIATION), max(0, TARGET_R - VARIATION)])
                limite_superior = np.array([min(255, TARGET_B + VARIATION), min(255, TARGET_G + VARIATION), min(255, TARGET_R + VARIATION)])

                mascara = cv2.inRange(frame_bgr, limite_inferior, limite_superior)

                if np.any(mascara == 255):
                    if ctypes.windll.user32.GetForegroundWindow() != 0:
                        time.sleep(delay_humano(0.003, 0.001))
                        quantidade_tiros = 3 
                        for _ in range(quantidade_tiros):
                            enviar_clique_humanizado()
                            time.sleep(delay_humano(0.005, 0.001))
                        time.sleep(delay_humano(0.030, 0.005))

            time.sleep(0.001)
    except Exception as e:
        print(f"Erro no loop: {e}")

# =======================================================================
# --- Lógica do Script 2: Sniper_PB ---
# =======================================================================
def ciclo_troca_arma_humanizado():
    time.sleep(delay_humano(0.001, 0.0005))
    pydirectinput.press('3')
    time.sleep(delay_humano(0.008, 0.002))
    pydirectinput.press('1')

def rodar_sniper_pb(parar_evento):
    largura_tela = ctypes.windll.user32.GetSystemMetrics(0)
    altura_tela = ctypes.windll.user32.GetSystemMetrics(1)
    mid_x = largura_tela // 2
    mid_y = altura_tela // 2

    bbox = (
        mid_x - SEARCH_RADIUS,
        mid_y - SEARCH_RADIUS,
        mid_x + SEARCH_RADIUS,
        mid_y + SEARCH_RADIUS
    )

    aimbot_ativo = True  
    script_suspenso = False

    print("==================================================")
    print(" [F10] FECHAR TUDO | [F9] PARAR | [Z] PAUSAR")
    print("==================================================")
    print("STATUS: MONITORAÇÃO JÁ INICIADA (MODO - SNIPER)")

    try:
        while not parar_evento.is_set():
            if obter_estado_tecla(VK_F12):
                ctypes.windll.user32.keybd_event(0x5B, 0, 0, 0)
                ctypes.windll.user32.keybd_event(0x44, 0, 0, 0)
                ctypes.windll.user32.keybd_event(0x44, 0, 2, 0)
                ctypes.windll.user32.keybd_event(0x5B, 0, 2, 0)
                print("\033[93m🖥️ Minimizado para a Área de Trabalho\033[0m")
                time.sleep(0.4)  

            if obter_estado_tecla(VK_Z):
                script_suspenso = not script_suspenso
                if script_suspenso:
                    print("\033[91m⏸️ SCRIPT PAUSADO (Z)\033[0m")
                else:
                    print("\033[92m▶️ SCRIPT RETOMADO (Z)\033[0m")
                time.sleep(0.4)

            if not script_suspenso and aimbot_ativo:
                screenshot = ImageGrab.grab(bbox=bbox)
                frame = np.array(screenshot)
                frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

                limite_inferior = np.array([max(0, TARGET_B - VARIATION), max(0, TARGET_G - VARIATION), max(0, TARGET_R - VARIATION)])
                limite_superior = np.array([min(255, TARGET_B + VARIATION), min(255, TARGET_G + VARIATION), min(255, TARGET_R + VARIATION)])

                mascara = cv2.inRange(frame_bgr, limite_inferior, limite_superior)

                if np.any(mascara == 255):
                    if ctypes.windll.user32.GetForegroundWindow() != 0:
                        time.sleep(delay_humano(0.012, 0.003))
                        enviar_clique_humanizado()
                        ciclo_troca_arma_humanizado()
                        time.sleep(delay_humano(0.180, 0.015))

            time.sleep(0.001)
    except Exception as e:
        print(f"Erro no loop: {e}")

# =======================================================================
# --- Gerenciamento da Interface e Threads ---
# =======================================================================
parar_evento = threading.Event()
thread_script = None

def iniciar_thread(funcao_alvo, nome_modo):
    global thread_script, parar_evento
    parar_evento.clear()
    
    btn_click.config(state=tk.DISABLED)
    btn_sniper.config(state=tk.DISABLED)
    btn_parar.config(state=tk.NORMAL)
    lbl_status.config(text=f"Status: Rodando ({nome_modo}) - [ATIVO]", fg="green")
    
    thread_script = threading.Thread(target=funcao_alvo, args=(parar_evento,), daemon=True)
    thread_script.start()

def parar_tudo():
    global parar_evento
    parar_evento.set()
    
    btn_click.config(state=tk.NORMAL)
    btn_sniper.config(state=tk.NORMAL)
    btn_parar.config(state=tk.DISABLED)
    lbl_status.config(text="Status: Parado / Interrompido (F9)", fg="red")

def fechar_aplicacao_completa():
    print("\033[91m❌ FECHANDO SCRIPT COMPLETAMENTE...\033[0m")
    parar_tudo()
    os._exit(0) # Encerra o processo de vez (como se fechasse pelo gerenciador de tarefas)

def alternar_visibilidade_janela():
    global janela_visivel
    if janela_visivel:
        root.withdraw()
        janela_visivel = False
    else:
        root.deiconify()
        root.attributes('-topmost', True)  
        try:
            hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
            if hwnd == 0:
                hwnd = root.winfo_id()
            ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
        except Exception:
            pass
        janela_visivel = True

# Monitor global: F2 (Menu), F9 (Parar), F10 (Fechar Completo), F5/F6 (Modos)
def escutar_atalhos_globais():
    global thread_script
    ultimo_estado_f2 = False
    ultimo_estado_f9 = False
    ultimo_estado_f10 = False
    ultimo_estado_f5 = False
    ultimo_estado_f6 = False

    while True:
        # F2 (MOSTRAR / OCULTAR MENU)
        f2_pressionado = obter_estado_tecla(0x71) 
        if f2_pressionado and not ultimo_estado_f2:
            root.after(0, alternar_visibilidade_janela)
            time.sleep(0.3)  
        ultimo_estado_f2 = f2_pressionado

        # F9 (EMERGÊNCIA / PARAR TUDO)
        f9_pressionado = obter_estado_tecla(VK_F9)
        if f9_pressionado and not ultimo_estado_f9:
            if thread_script and thread_script.is_alive():
                parar_tudo()
                print("\033[91m🚨 EMERGÊNCIA: Tudo Parado pelo F9!\033[0m")
            time.sleep(0.3)
        ultimo_estado_f9 = f9_pressionado

        # F10 (FECHAR SCRIPT POR COMPLETO)
        f10_pressionado = obter_estado_tecla(VK_F10)
        if f10_pressionado and not ultimo_estado_f10:
            fechar_aplicacao_completa()
        ultimo_estado_f10 = f10_pressionado

        # F5 (ATIVAR MODO CLICK)
        f5_pressionado = obter_estado_tecla(VK_F5)
        if f5_pressionado and not ultimo_estado_f5:
            parar_tudo()
            time.sleep(0.2)
            iniciar_thread(rodar_click_pb, "Click_PB")
            print("\033[92m🎮 MODO CLICK ATIVADO (F5)\033[0m")
            time.sleep(0.3)
        ultimo_estado_f5 = f5_pressionado

        # F6 (ATIVAR MODO SNIPER)
        f6_pressionado = obter_estado_tecla(VK_F6)
        if f6_pressionado and not ultimo_estado_f6:
            parar_tudo()
            time.sleep(0.2)
            iniciar_thread(rodar_sniper_pb, "Sniper_PB")
            print("\033[92m🎯 MODO SNIPER ATIVADO (F6)\033[0m")
            time.sleep(0.3)
        ultimo_estado_f6 = f6_pressionado

        time.sleep(0.05)

# =======================================================================
# --- Interface Gráfica (Tkinter) ---
# =======================================================================
root = tk.Tk()
root.title("Launcher Integrado - PB")
root.geometry("380x280")
root.resizable(False, False)

janela_visivel = False
root.withdraw()

kernel32 = ctypes.WinDLL('kernel32')
user32 = ctypes.WinDLL('user32')
hWnd = kernel32.GetConsoleWindow()
if hWnd != 0:
    user32.ShowWindow(hWnd, 0)  

titulo = tk.Label(root, text="Selecione o Modo", font=("Arial", 14, "bold"))
titulo.pack(pady=15)

btn_click = tk.Button(root, text="🎮 [F5] Ativar Click_PB", font=("Arial", 11), bg="#d0f0c0", width=28, command=lambda: iniciar_thread(rodar_click_pb, "Click_PB"))
btn_click.pack(pady=5)

btn_sniper = tk.Button(root, text="🎯 [F6] Ativar Sniper_PB", font=("Arial", 11), bg="#d0f0c0", width=28, command=lambda: iniciar_thread(rodar_sniper_pb, "Sniper_PB"))
btn_sniper.pack(pady=5)

btn_parar = tk.Button(root, text="🛑 [F9] Parar (Emergência)", font=("Arial", 11), bg="#ff9999", width=28, state=tk.DISABLED, command=parar_tudo)
btn_parar.pack(pady=10)

lbl_status = tk.Label(root, text="Status: Parado | Use F10 para Fechar Tudo", font=("Arial", 8), fg="gray")
lbl_status.pack(pady=5)

t_atalhos = threading.Thread(target=escutar_atalhos_globais, daemon=True)
t_atalhos.start()

def ao_fechar():
    fechar_aplicacao_completa()

root.protocol("WM_DELETE_WINDOW", ao_fechar)
root.mainloop()