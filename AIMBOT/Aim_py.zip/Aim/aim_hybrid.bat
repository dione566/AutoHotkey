@echo off
python aim_hybrid.py
pause