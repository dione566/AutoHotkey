import ctypes
import time
import os
import sys
import random
from PIL import ImageGrab
import cv2
import numpy as np
import pydirectinput  # <-- Biblioteca mais segura para jogos DirectX

# Desativar o fail-safe do pydirectinput para evitar travamentos no meio do jogo
pydirectinput.FAILSAFE = False

# =======================================================================
# --- Configurações Iniciais e APIs do Windows ---
# =======================================================================
VK_F6 = 0x75   # ALTERNAR (ATIVAR / DESATIVAR)
VK_F7 = 0x76   # SAIR
VK_Z  = 0x5A   # PAUSAR

TARGET_B = 0
TARGET_G = 0
TARGET_R = 255
VARIATION = 15      
SEARCH_RADIUS = 250  # Reduzido levemente para otimizar o uso de CPU (Varredura mais rápida)

def obter_estado_tecla(vkey):
    return (ctypes.windll.user32.GetAsyncKeyState(vkey) & 0x8000) != 0

def delay_humano(mu, sigma):
    """
    Gera um delay baseado em uma distribuição normal (Curva de Gauss).
    Faz com que a maioria dos tempos fique perto da média (mu), 
    mas ocasionalmente gera um reflexo mais lento ou mais rápido, como um humano.
    """
    delay = random.gauss(mu, sigma)
    # Garante que o delay não seja negativo ou bizarramente baixo devido à flutuação
    return max(mu - (2 * sigma), min(delay, mu + (2 * sigma)))

def enviar_clique_humanizado():
    pydirectinput.mouseDown(button='left')
    time.sleep(delay_humano(0.06, 0.005)) # Tempo que o dedo passa pressionando o botão
    pydirectinput.mouseUp(button='left')

def ciclo_troca_arma_humanizado():
    # Delay inicial após o tiro antes de tirar a mão do mouse e focar no teclado
    time.sleep(delay_humano(0.010, 0.005))
    
    # Puxa Faca (Tecla 3)
    pydirectinput.press('3')
    
    # Intervalo entre soltar uma tecla e apertar a outra (o "tempo de viagem" do dedo)
    time.sleep(delay_humano(0.030, 0.006))
    
    # Puxa Sniper (Tecla 1)
    pydirectinput.press('1')

# Dimensões dinâmicas da tela principal
largura_tela = ctypes.windll.user32.GetSystemMetrics(0)
altura_tela = ctypes.windll.user32.GetSystemMetrics(1)
mid_x = largura_tela // 2
mid_y = altura_tela // 2

bbox = (
    mid_x - SEARCH_RADIUS,
    mid_y - SEARCH_RADIUS,
    mid_x + SEARCH_RADIUS,
    mid_y + SEARCH_RADIUS
)

aimbot_ativo = False
script_suspenso = False

os.system('cls' if os.name == 'nt' else 'clear')
print("==================================================")
print(" [F6] ATIVAR/DESATIVAR | [Z] PAUSAR | [F7] SAIR")
print("==================================================")
print("STATUS: AGUARDANDO ATIVAÇÃO (MODO SEGURO DIRECTX)")

# =======================================================================
# --- Loop Principal ---
# =======================================================================
try:
    while True:
        if obter_estado_tecla(VK_Z):
            script_suspenso = not script_suspenso
            if script_suspenso:
                aimbot_ativo = False
                print("\033[91m❌ SCRIPT: SUSPENDIDO\033[0m")
            else:
                print("\033[92m✅ SCRIPT: REATIVADO\033[0m")
            time.sleep(0.4)  # Debounce para evitar cliques múltiplos

        if obter_estado_tecla(VK_F7):
            print("Encerrando execução...")
            break

        if not script_suspenso:
            # --- NOVA LÓGICA DE ALTERNÂNCIA (TOGGLE) NO F6 ---
            if obter_estado_tecla(VK_F6):
                aimbot_ativo = not aimbot_ativo  # Inverte o estado atual
                if aimbot_ativo:
                    print("\033[92m🎯 MONITORAÇÃO: ATIVA\033[0m")
                else:
                    print("\033[93m⚡ MONITORAÇÃO: OFF\033[0m")
                time.sleep(0.4)  # Pequena pausa (debounce) para não ativar/desativar repetidamente no mesmo clique

            if aimbot_ativo:
                screenshot = ImageGrab.grab(bbox=bbox)
                frame = np.array(screenshot)
                frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

                limite_inferior = np.array([
                    max(0, TARGET_B - VARIATION),
                    max(0, TARGET_G - VARIATION),
                    max(0, TARGET_R - VARIATION)
                ])
                limite_superior = np.array([
                    min(255, TARGET_B + VARIATION),
                    min(255, TARGET_G + VARIATION),
                    min(255, TARGET_R + VARIATION)
                ])

                mascara = cv2.inRange(frame_bgr, limite_inferior, limite_superior)

                if np.any(mascara == 255):
                    if ctypes.windll.user32.GetForegroundWindow() != 0:
                        # Simula tempo de reação
                        time.sleep(delay_humano(0.135, 0.015))
                        
                        enviar_clique_humanizado()
                        ciclo_troca_arma_humanizado()
                        
                        # Cooldown da animação de puxar o ferrolho/recarga
                        time.sleep(delay_humano(0.660, 0.030))

        # Evita looping idêntico de clock de CPU de 1ms fixo
        time.sleep(delay_humano(0.002, 0.0005))

except KeyboardInterrupt:
    print("\nExecução interrompida manualmente.")
finally:
    print("Script finalizado.")
    input("Pressione Enter para fechar esta janela...")