@echo off
title Restaurador de Chaves ADB
color 0b

echo ======================================================
echo    RESTAURANDO AUTORIZACAO ADB (BACKUP)
echo ======================================================
echo.

:: Define os caminhos de origem e destino
set "ORIGEM=C:\Users\user\Documents\ADB BACKUP S20 FE"
set "DESTINO=%USERPROFILE%\.android"

:: Verifica se a pasta de origem existe
if not exist "%ORIGEM%" (
    color 0c
    echo [ERRO] A pasta de origem %ORIGEM% nao foi encontrada.
    echo Verifique se o caminho do Desktop esta correto.
    pause
    exit
)

:: Cria a pasta .android caso ela ainda nao exista no perfil do usuario
if not exist "%DESTINO%" (
    echo [INFO] Criando pasta %DESTINO%...
    mkdir "%DESTINO%"
)

echo [PROCESSANDO] Copiando chaves para %DESTINO%...
echo.

:: Copia os arquivos ( /Y para sobrescrever sem perguntar )
copy /Y "%ORIGEM%\adbkey" "%DESTINO%\"
copy /Y "%ORIGEM%\adbkey.pub" "%DESTINO%\"

echo.
echo ======================================================
echo    CONCLUIDO! As chaves foram restauradas.
echo    Agora voce ja pode conectar seu celular.
echo ======================================================
echo.
pause