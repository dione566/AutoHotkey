﻿; ========================================================================
; Aimbot YOLO + AHK - Versão Otimizada (Anti-Fuga / Maior Aderência)
; ========================================================================

if not A_IsAdmin
{
    Run *RunAs "%A_ScriptFullPath%"
    ExitApp
}

#NoEnv
#SingleInstance Force
SetWorkingDir %A_ScriptDir%
SendMode Input
CoordMode, Mouse, Screen
SetBatchLines, -1

; --- CONFIGURAÇÕES DE MOVIMENTO ---
BaseSens      := 0.1        ; Sensibilidade base de suavização
DeadZone      := 0.1        ; Zona morta ajustada para evitar trepidação leve
SearchActive  := False

; Variáveis para memória de último alvo (evita perder se a IA falhar 1 frame)
LastValidX    := 0
LastValidY    := 0
LostFrames    := 0
MaxLostFrames := 5          ; Quantos ciclos aguenta sem atualizar antes de desistir

WheelUp::
    SearchActive := True
    SetTimer, MainLoop, 3  ; Alterado para 10ms (mais estável e fluido que 1ms)
    ToolTip, SEARCH: ON, 10, 10
return

WheelDown::
    SearchActive := False
    SetTimer, MainLoop, Off
    ToolTip
return

~F9::ExitApp

MainLoop:
    if (SearchActive = False)
        return

    MouseGetPos, MouseX, MouseY
    FileRead, ConteudoAlvo, alvo.txt

    if (ConteudoAlvo = "")
        return

    if (ConteudoAlvo = "none")
    {
        LostFrames++
        ; Se perdeu por poucos frames, tenta manter a direção anterior brevemente
        if (LostFrames < MaxLostFrames and LastValidX != 0)
        {
            FoundX := LastValidX
            FoundY := LastValidY
        }
        else
        {
            ToolTip, IA nao achou ninguem, 10, 10
            return
        }
    }
    else
    {
        ; Resetador de contador de perda quando acha o alvo com sucesso
        LostFrames := 0
        StringSplit, Pos, ConteudoAlvo, `,
        FoundX := Pos1 + 0
        FoundY := Pos2 + 0
        
        ; Salva última posição válida
        LastValidX := FoundX
        LastValidY := FoundY
    }

    MouseX := MouseX + 0
    MouseY := MouseY + 0

    MoveX := FoundX - MouseX
    MoveY := FoundY - MouseY
    DistTotal := Sqrt(MoveX * MoveX + MoveY * MoveY)

    ; Se já estiver na zona morta, crava
    if (DistTotal <= DeadZone)
    {
        ToolTip, Alvo Cravado!, 10, 10
        return
    }

    ; --- MATEMÁTICA DE VELOCIDADE DINÂMICA ---
    ; Quanto mais longe o alvo estiver, maior o limite de movimento por ciclo (evita perder o alvo)
    MaxMovimentoDynamic := Round(DistTotal * 0.4)
    if (MaxMovimentoDynamic < 4)
        MaxMovimentoDynamic := 4
    if (MaxMovimentoDynamic > 25)
        MaxMovimentoDynamic := 25

    StepX := (MoveX * BaseSens)
    StepY := (MoveY * BaseSens)

    ; Aplica o teto dinâmico
    if (StepX > MaxMovimentoDynamic)
        StepX := MaxMovimentoDynamic
    else if (StepX < -MaxMovimentoDynamic)
        StepX := -MaxMovimentoDynamic

    if (StepY > MaxMovimentoDynamic)
        StepY := MaxMovimentoDynamic
    else if (StepY < -MaxMovimentoDynamic)
        StepY := -MaxMovimentoDynamic

    FinalX := Round(StepX)
    FinalY := Round(StepY)

    ; Força passo mínimo de 1 pixel se houver distância pendente
    if (FinalX = 0 and MoveX != 0)
        FinalX := (MoveX > 0) ? 1 : -1

    if (FinalY = 0 and MoveY != 0)
        FinalY := (MoveY > 0) ? 1 : -1

    ; Executa o movimento via DllCall
    if (FinalX != 0)
        DllCall("mouse_event", "UInt", 0x0001, "Int", FinalX, "Int", 0, "UInt", 0, "UPtr", 0)

    if (FinalY != 0)
        DllCall("mouse_event", "UInt", 0x0001, "Int", 0, "Int", FinalY, "UInt", 0, "UPtr", 0)

    DistArredondada := Round(DistTotal)
    ToolTip, Seguindo... Dist: %DistArredondada% px, 10, 10
return