import cv2
import mss
import numpy as np
from ultralytics import YOLO

# ==========================================
# CONFIGURAÇÃO
# ==========================================
# Área da tela que o Python vai "olhar"
monitor = {"top": 200, "left": 300, "width": 400, "height": 300}

# Raio do círculo de busca (em pixels).
# Aumente = aceita alvos mais longe do centro.
# Diminua = só mira no que está bem no meio.
RAIO_BUSCA = 100

# ==========================================
# CARREGA MODELO
# ==========================================
print("Carregando modelo YOLO... aguarde.")
model = YOLO("best.pt")
print("Modelo carregado! Abrindo janela de detecção...")
print("Pressione ESC na janela de vídeo para sair.")

# ==========================================
# LOOP PRINCIPAL
# ==========================================
with mss.mss() as sct:
    while True:
        # 1. Captura a tela
        img = np.array(sct.grab(monitor))
        frame = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

        # 2. Roda a IA
        results = model(frame, verbose=False)

        melhor_alvo = None
        menor_distancia = 999999

        centro_x = monitor["width"] // 2
        centro_y = monitor["height"] // 2

        # =====================================
        # CÍRCULO DE BUSCA VISÍVEL + MIRA
        # =====================================
        # Círculo principal (amarelo, grosso)
        cv2.circle(frame, (centro_x, centro_y), RAIO_BUSCA, (0, 255, 255), 2)

        # Círculo interno tracejado (referência visual)
        cv2.circle(frame, (centro_x, centro_y), RAIO_BUSCA // 2, (0, 255, 255), 1)

        # Crosshair (mira) no centro
        tam = 15
        cv2.line(frame, (centro_x - tam, centro_y), (centro_x + tam, centro_y),
                 (0, 0, 255), 2)
        cv2.line(frame, (centro_x, centro_y - tam), (centro_x, centro_y + tam),
                 (0, 0, 255), 2)
        cv2.circle(frame, (centro_x, centro_y), 3, (0, 0, 255), -1)

        # Texto informativo com o raio atual
        cv2.putText(frame, f"Raio: {RAIO_BUSCA}px",
                    (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

        # =====================================
        # DETECÇÃO DE INIMIGOS
        # =====================================
        for r in results:
            for box in r.boxes:
                # Só considera pessoas
                if model.names[int(box.cls[0])] != "person":
                    continue

                x1, y1, x2, y2 = map(int, box.xyxy[0])
                alvo_cx = (x1 + x2) // 2
                alvo_cy = (y1 + y2) // 2

                # Distância² até o centro (mais rápido que usar sqrt)
                dist = (alvo_cx - centro_x) ** 2 + (alvo_cy - centro_y) ** 2

                # Fora do círculo? Desenha em vermelho fino e ignora
                if dist > RAIO_BUSCA ** 2:
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 1)
                    continue

                # Dentro do círculo: desenha em verde
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, "Inimigo", (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                # Linha do centro até o alvo (feedback visual)
                cv2.line(frame, (centro_x, centro_y), (alvo_cx, alvo_cy),
                         (0, 255, 0), 1)

                # Guarda o mais próximo
                if dist < menor_distancia:
                    menor_distancia = dist
                    melhor_alvo = (alvo_cx, alvo_cy)

        # Destaca o alvo escolhido com um círculo vermelho em volta
        if melhor_alvo:
            cv2.circle(frame, melhor_alvo, 20, (0, 0, 255), 2)
            cv2.putText(frame, "ALVO", (melhor_alvo[0] + 22, melhor_alvo[1] + 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

        # =====================================
        # SALVA POSIÇÃO PARA O AHK
        # =====================================
        with open("alvo.txt", "w") as f:
            if melhor_alvo:
                tela_x = melhor_alvo[0] + monitor["left"]
                tela_y = melhor_alvo[1] + monitor["top"]
                f.write(f"{tela_x},{tela_y}")
            else:
                f.write("none")

        # =====================================
        # MOSTRA A JANELA
        # =====================================
        cv2.imshow("Deteccao - Pressione ESC para sair", frame)

        if cv2.waitKey(1) & 0xFF == 27:
            break

cv2.destroyAllWindows()