import cv2
import mss
import numpy as np
import os
import time
from ultralytics import YOLO

# ==========================================
# CONFIGURAÇÃO
# ==========================================
# Área da tela que o Python vai "olhar"
monitor = {"top": 200, "left": 300, "width": 400, "height": 300}

RAIO_BUSCA       = 100    # Raio do círculo de busca (px)
CONF_THRESHOLD   = 0.35   # Confiança mínima da IA (evita falsos positivos)
STICKY_RADIUS    = 80     # Distância que mantém o alvo travado (evita pular entre inimigos)
STICKY_FRAMES    = 10     # Frames que "lembra" do alvo perdido antes de soltar

def atomic_write(path, content):
    """Escrita atômica com retry para evitar WinError 5 (arquivo em uso)."""
    tmp = path + ".tmp"
    try:
        with open(tmp, "w") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno()) 
        
        # Tenta substituir o arquivo original com retry
        max_retries = 5
        delay = 0.01 
        for attempt in range(max_retries):
            try:
                os.replace(tmp, path)
                return # Sucesso
            except PermissionError:
                if attempt == max_retries - 1:
                    raise
                time.sleep(delay)
                delay *= 2 # Espera 10ms, 20ms, 40ms...
    
    except PermissionError:
        # Fallback: o AHK está com o arquivo travado. Escreve direto.
        # O AHK vai ignorar se ler pela metade graças ao RegExMatch.
        with open(path, "w") as f:
            f.write(content)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass

# ==========================================
# CARREGA MODELO
# ==========================================
print("Carregando modelo YOLO... aguarde.")
model = YOLO("best.pt")
print("Modelo carregado! Pressione ESC na janela para sair.")

# ==========================================
# ESTADO DE STICKY TARGET (Memória)
# ==========================================
last_target   = None       
lost_counter  = 0
fps_history   = []

# ==========================================
# LOOP PRINCIPAL
# ==========================================
with mss.MSS() as sct: # Corrigido o DeprecationWarning aqui
    while True:
        t0 = time.time()
        img   = np.array(sct.grab(monitor))
        frame = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

        results = model(frame, verbose=False, conf=CONF_THRESHOLD)

        centro_x = monitor["width"]  // 2
        centro_y = monitor["height"] // 2

        # ---------- Desenho da Mira ----------
        cv2.circle(frame, (centro_x, centro_y), RAIO_BUSCA, (0, 255, 255), 2)
        cv2.circle(frame, (centro_x, centro_y), RAIO_BUSCA // 2, (0, 255, 255), 1)
        tam = 15
        cv2.line(frame, (centro_x - tam, centro_y), (centro_x + tam, centro_y), (0, 0, 255), 2)
        cv2.line(frame, (centro_x, centro_y - tam), (centro_x, centro_y + tam), (0, 0, 255), 2)
        cv2.circle(frame, (centro_x, centro_y), 3, (0, 0, 255), -1)

        # ---------- Coleta de Candidatos ----------
        candidatos = []
        for r in results:
            for box in r.boxes:
                if model.names[int(box.cls[0])] != "person":
                    continue
                conf = float(box.conf[0])
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cx = (x1 + x2) // 2
                cy = (y1 + y2) // 2
                d2 = (cx - centro_x) ** 2 + (cy - centro_y) ** 2

                # Fora do raio de busca
                if d2 > RAIO_BUSCA ** 2:
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 1)
                    continue

                candidatos.append({
                    "cx": cx, "cy": cy, "d2": d2, "conf": conf,
                    "box": (x1, y1, x2, y2),
                })

        # ---------- Lógica Sticky Target ----------
        melhor_alvo = None
        sticky_em_uso = False

        if candidatos:
            # 1) Tenta manter o alvo anterior (Sticky)
            if last_target is not None and lost_counter < STICKY_FRAMES:
                best_d2 = STICKY_RADIUS ** 2
                sticky_choice = None
                for c in candidatos:
                    d2 = (c["cx"] - last_target[0]) ** 2 + (c["cy"] - last_target[1]) ** 2
                    if d2 < best_d2:
                        best_d2 = d2
                        sticky_choice = c
                if sticky_choice is not None:
                    melhor_alvo = (sticky_choice["cx"], sticky_choice["cy"])
                    sticky_em_uso = True

            # 2) Se não achou sticky, pega o mais perto do centro
            if melhor_alvo is None:
                mais_perto = min(candidatos, key=lambda c: c["d2"])
                melhor_alvo = (mais_perto["cx"], mais_perto["cy"])

            last_target = melhor_alvo
            lost_counter = 0
        else:
            lost_counter += 1
            if lost_counter >= STICKY_FRAMES:
                last_target = None

        # ---------- Desenho dos Candidatos ----------
        for c in candidatos:
            x1, y1, x2, y2 = c["box"]
            cor = (0, 255, 0) # Verde normal
            if melhor_alvo and c["cx"] == melhor_alvo[0] and c["cy"] == melhor_alvo[1]:
                cor = (0, 200, 255) # Laranja para o alvo travado
            cv2.rectangle(frame, (x1, y1), (x2, y2), cor, 2)
            cv2.putText(frame, f"{c['conf']:.2f}", (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, cor, 1)

        if melhor_alvo:
            cv2.circle(frame, melhor_alvo, 22, (0, 0, 255), 2)
            tag = "ALVO (LOCK)" if sticky_em_uso else "ALVO"
            cv2.putText(frame, tag, (melhor_alvo[0] + 24, melhor_alvo[1] + 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

        # ---------- Escrita Segura ----------
        if melhor_alvo:
            tx = melhor_alvo[0] + monitor["left"]
            ty = melhor_alvo[1] + monitor["top"]
            atomic_write("alvo.txt", f"{tx},{ty}")
        else:
            atomic_write("alvo.txt", "none")

        # ---------- HUD ----------
        fps_history.append(time.time() - t0)
        if len(fps_history) > 30:
            fps_history.pop(0)
        fps = 1.0 / (sum(fps_history) / len(fps_history))
        cv2.putText(frame, f"YOLO FPS: {fps:4.1f}", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        cv2.putText(frame, f"Candidatos: {len(candidatos)}", (10, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

        # ---------- Mostra Janela ----------
        cv2.imshow("Deteccao - Pressione ESC para sair", frame)
        if cv2.waitKey(1) & 0xFF == 27:
            break

cv2.destroyAllWindows()