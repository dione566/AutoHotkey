﻿; ========================================================================
; Aimbot YOLO + AHK - Versão 2 (Sticky Lock + Adaptive Speed)
; ========================================================================

if not A_IsAdmin
{
    Run *RunAs "%A_ScriptFullPath%"
    ExitApp
}

#NoEnv
#SingleInstance Force
SetWorkingDir %A_ScriptDir%
SendMode Input
CoordMode, Mouse, Screen
SetBatchLines, -1

; --- CONFIG ---
DeadZone      := 1          ; px de tolerância final
SearchActive  := False

; Memória de alvo perdido (evita perder em frames onde YOLO falha)
LastValidX    := 0
LastValidY    := 0
LostFrames    := 0
MaxLostFrames := 6

WheelUp::
    SearchActive := True
    SetTimer, MainLoop, 10    ; 10ms é estável (3ms é instável no AHK)
    ToolTip, SEARCH: ON, 10, 10
return

WheelDown::
    SearchActive := False
    SetTimer, MainLoop, Off
    ToolTip
return

~F9::ExitApp

MainLoop:
    if (!SearchActive)
        return

    ; --- LÊ ARQUIVO ---
    FileRead, ConteudoAlvo, alvo.txt
    ConteudoAlvo := Trim(ConteudoAlvo)

    UsandoMemoria := False

    if (ConteudoAlvo = "none" or ConteudoAlvo = "")
    {
        LostFrames++
        if (LostFrames < MaxLostFrames and LastValidX != 0)
        {
            FoundX := LastValidX
            FoundY := LastValidY
            UsandoMemoria := True
        }
        else
        {
            ToolTip, Sem alvo, 10, 10
            return
        }
    }
    else
    {
        ; Valida formato "X,Y" — evita bug de leitura parcial
        if !RegExMatch(ConteudoAlvo, "^(\d+),(\d+)$", Pos)
            return

        LostFrames := 0
        FoundX := Pos1 + 0
        FoundY := Pos2 + 0
        LastValidX := FoundX
        LastValidY := FoundY
    }

    ; --- CALCULA DISTÂNCIA ---
    MouseGetPos, MouseX, MouseY
    MoveX := FoundX - MouseX
    MoveY := FoundY - MouseY
    DistTotal := Sqrt(MoveX * MoveX + MoveY * MoveY)

    if (DistTotal <= DeadZone)
    {
        ToolTip, Cravado!, 10, 10
        return
    }

    ; --- SENSIBILIDADE ADAPTATIVA ---
    ; Longe = rápido (chega logo), perto = preciso (não treme)
    if (DistTotal > 200)
        Sens := 0.40
    else if (DistTotal > 50)
        Sens := 0.28
    else
        Sens := 0.15

    FinalX := Round(MoveX * Sens)
    FinalY := Round(MoveY * Sens)

    ; Garante mínimo de 1px se ainda está fora da deadzone
    if (FinalX = 0 and Abs(MoveX) > DeadZone)
        FinalX := (MoveX > 0) ? 1 : -1
    if (FinalY = 0 and Abs(MoveY) > DeadZone)
        FinalY := (MoveY > 0) ? 1 : -1

    ; --- MOVIMENTO ---
    if (FinalX != 0)
        DllCall("mouse_event", "UInt", 0x0001, "Int", FinalX, "Int", 0, "UInt", 0, "UPtr", 0)
    if (FinalY != 0)
        DllCall("mouse_event", "UInt", 0x0001, "Int", 0, "Int", FinalY, "UInt", 0, "UPtr", 0)

    ; --- HUD ---
    DistArredondada := Round(DistTotal)
    if (UsandoMemoria)
        ToolTip, Mem... %DistArredondada%px, 10, 10
    else
        ToolTip, Seguindo %DistArredondada%px, 10, 10
return