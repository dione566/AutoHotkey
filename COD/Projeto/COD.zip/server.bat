@echo off
cd /d "%~dp0"
python detector.py
pause