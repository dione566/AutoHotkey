@off
python Pre_Carregar_Cache.py
pause