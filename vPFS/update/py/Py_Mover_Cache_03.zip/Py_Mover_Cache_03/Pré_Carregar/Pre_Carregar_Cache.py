import os
import base64
import tkinter as tk
from tkinter import filedialog
from io import BytesIO
from PIL import Image
import cv2
from tqdm import tqdm
import threading

# BLOQUEIO ABSOLUTO DE LOGS DO OPENCV E FFMPEG NO WINDOWS
os.environ["OPENCV_LOG_LEVEL"] = "FATAL"
os.environ["FFMPEG_LOG_LEVEL"] = "QUIET"

PASTA_CACHE_GLOBAL = r"E:\gts\new"
PASTA_OUTPUT_CACHE = os.path.join(PASTA_CACHE_GLOBAL, '.cache_midias')

EXTENSOES_IMAGEM = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']
EXTENSOES_VIDEO = ['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.3gp', '.mpg', '.m4v']

def decodificar_nome_b64(string_b64):
    b64 = string_b64
    while len(b64) % 4 != 0:
        b64 += '='
    try:
        binario = base64.b64decode(b64)
        return binario.decode('utf-8', errors='replace')
    except Exception:
        return string_b64

def extrair_extensao_real(nome_arquivo):
    partes = nome_arquivo.split('.')
    if len(partes) < 2:
        return ""
    ext_falsa_b64 = partes[-1]
    return decodificar_nome_b64(ext_falsa_b64).lower()

def carregar_e_recortar_arquivo(caminho_arquivo):
    try:
        tamanho = os.path.getsize(caminho_arquivo)
        with open(caminho_arquivo, 'rb') as f:
            if tamanho > 32:
                f.seek(32)
                return f.read()
            return f.read()
    except Exception:
        return None

def gerar_base64_imagem(dados_binarios):
    if not dados_binarios:
        return None
    try:
        img = Image.open(BytesIO(dados_binarios))
        img = img.convert('RGB')
        img.thumbnail((160, 160))
        
        canvas = Image.new('RGB', (160, 160), (0, 0, 0))
        offset = ((160 - img.width) // 2, (160 - img.height) // 2)
        canvas.paste(img, offset)
        
        buffered = BytesIO()
        canvas.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
        return f"data:image/png;base64,{img_str}"
    except Exception:
        return None

def _capturar_frame_video(caminho_limpo, resultado):
    try:
        video = cv2.VideoCapture(caminho_limpo)
        if not video.isOpened():
            return
        
        total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
        if total_frames <= 0:
            video.release()
            return
            
        # PULA 28 FRAMES
        frame_alvo = 28 if total_frames > 29 else (total_frames // 2)
        video.set(cv2.CAP_PROP_POS_FRAMES, frame_alvo)
        
        sucesso, frame = video.read()
        
        if not sucesso:
            video.set(cv2.CAP_PROP_POS_FRAMES, 0)
            for _ in range(frame_alvo + 1):
                sucesso, frame = video.read()
                if not sucesso:
                    break
        
        video.release()
        
        if sucesso and frame is not None:
            frame_redimensionado = cv2.resize(frame, (160, 160), interpolation=cv2.INTER_AREA)
            sucesso_encode, buffer = cv2.imencode('.png', frame_redimensionado)
            if sucesso_encode:
                img_str = base64.b64encode(buffer).decode('utf-8')
                resultado['base64'] = f"data:image/png;base64,{img_str}"
    except Exception:
        pass

def gerar_base64_video_com_timeout(caminho_original, ext_real, timeout=0.8):
    caminho_temp = os.path.join(PASTA_OUTPUT_CACHE, f"temp_thumb_proc.{ext_real}")
    resultado = {'base64': None}
    
    try:
        dados_limpos = carregar_e_recortar_arquivo(caminho_original)
        if not dados_limpos:
            return None
            
        with open(caminho_temp, 'wb') as f_temp:
            f_temp.write(dados_limpos)
        
        thread = threading.Thread(target=_capturar_frame_video, args=(caminho_temp, resultado))
        thread.daemon = True
        thread.start()
        thread.join(timeout)
        
    except Exception:
        pass
    finally:
        if os.path.exists(caminho_temp):
            try: os.remove(caminho_temp)
            except: pass
            
    return resultado['base64']

def processar_midias():
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    
    pasta_selecionada = filedialog.askdirectory(title="Selecione a pasta de Mídias para Escanear")
    root.destroy()
    
    if not pasta_selecionada:
        print("[AVISO] Nenhuma pasta foi selecionada.")
        return

    os.makedirs(PASTA_OUTPUT_CACHE, exist_ok=True)
    
    arquivos_encontrados = []
    for raiz, _, arquivos in os.walk(pasta_selecionada):
        for arquivo in arquivos:
            if '.' in arquivo and arquivo != "temp_inject.ps1":
                arquivos_encontrados.append(os.path.join(raiz, arquivo))

    if not arquivos_encontrados:
        print("[AVISO] Nenhum arquivo válido encontrado.")
        return

    print(f"\n[INFO] Encontrados {len(arquivos_encontrados)} arquivos. Gerando Cache Turbo...")
    
    barra_progresso = tqdm(arquivos_encontrados, desc="Processando", unit="arq")
    
    for caminho_completo in barra_progresso:
        try:
            nome_original_hd = os.path.basename(caminho_completo)
            nome_pasta_atual = os.path.basename(os.path.dirname(caminho_completo))
            
            info_tela = f"[{nome_pasta_atual}] {nome_original_hd}"[:45]
            barra_progresso.set_description(f"Lendo: {info_tela:<45}")
            
            nome_base_arquivo = os.path.splitext(nome_original_hd)[0]
            nome_thumb_txt = f"{nome_base_arquivo}_thumb.png"
            caminho_thumb_final = os.path.join(PASTA_OUTPUT_CACHE, nome_thumb_txt)
            
            # ALTERAÇÃO AQUI: Remove o 'continue' anterior para que passe direto e substitua.
            # Se der erro ao tentar remover um arquivo preso, ele segue em frente para tentar reescrevê-lo.
            if os.path.exists(caminho_thumb_final):
                try: os.remove(caminho_thumb_final)
                except: pass
                
            ext_real = extrair_extensao_real(nome_original_hd)
            thumb_base64 = None
            
            if f".{ext_real}" in EXTENSOES_IMAGEM:
                dados_limpos = carregar_e_recortar_arquivo(caminho_completo)
                if dados_limpos:
                    thumb_base64 = gerar_base64_imagem(dados_limpos)
                
            elif f".{ext_real}" in EXTENSOES_VIDEO:
                thumb_base64 = gerar_base64_video_com_timeout(caminho_completo, ext_real, timeout=0.8)
                
            if thumb_base64:
                with open(caminho_thumb_final, 'w', encoding='utf-8', errors='replace') as f:
                    f.write(thumb_base64)
                    
        except Exception:
            continue

    print(f"\n[SUCESSO] Varredura completa de todas as mídias em: {PASTA_OUTPUT_CACHE}")
    os.system("pause")

if __name__ == '__main__':
    processar_midias()