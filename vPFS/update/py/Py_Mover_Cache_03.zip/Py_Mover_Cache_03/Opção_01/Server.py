from http.server import BaseHTTPRequestHandler, HTTPServer
import os
import json
import shutil
import threading
import queue
import keyboard
import tkinter as tk
from tkinter import filedialog
from urllib.parse import urlparse, parse_qs

# Lock para garantir thread-safety ao ler/escrever as pastas globais
config_lock = threading.Lock()

# PASTA RAIZ PREPARADA FIXA E SEUS COMPONENTES PADRÃO
PASTA_BASE_MANUAL = r"E:\gts"
PASTA_DESTINO_MANUAL = r"E:\gts\movidos"
PASTA_CACHE_GLOBAL = r"D:\gts\Google_Cache"

# Fila para enviar solicitações de interface para a thread principal
interface_queue = queue.Queue()

def limpar_console():
    """Limpa a tela do console de forma multiplataforma."""
    os.system('cls' if os.name == 'nt' else 'clear')

def exibir_menu_status():
    """Exibe o painel de informações atualizado e limpo."""
    limpar_console()
    with config_lock:
        base = PASTA_BASE_MANUAL
        destino = PASTA_DESTINO_MANUAL
        cache = PASTA_CACHE_GLOBAL

    print("=" * 60)
    print(" SERVIDOR DE CACHE BASE64 ATIVO E OTIMIZADO")
    print(" URL local: http://127.0.0.1:8080")
    print(f" Pasta Raiz Padrão: {base}")
    print(f" Pasta Destino:     {destino}")
    print(f" Pasta Cache:       {cache}")
    print("=" * 60)
    print(" ATALHOS CASO PRECISE ALTERAR TEMPORARIAMENTE:")
    print(" [F1] -> Redefinir Pasta de Origem")
    print(" [F2] -> Redefinir Pasta de Destino")
    print(" [F3] -> Redefinir Pasta do Cache")
    print("-" * 60)
    print(" Aguardando comandos do painel...")

def disparar_selecao(tipo):
    """Apenas coloca a solicitação na fila para a thread principal processar."""
    interface_queue.put(tipo)

def processar_selecao_pasta(tipo):
    """Executa o diálogo do Tkinter com segurança na thread principal se precisar mudar algo via hotkey."""
    global PASTA_BASE_MANUAL, PASTA_DESTINO_MANUAL, PASTA_CACHE_GLOBAL
    
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    
    try:
        if tipo == "origem":
            print("\n[F1] Abrindo janela de seleção de ORIGEM...")
            pasta = filedialog.askdirectory(title="Selecione a nova Pasta de Origem")
            if pasta:
                with config_lock:
                    PASTA_BASE_MANUAL = os.path.normpath(pasta)
                exibir_menu_status()
                print(f"[CONFIG] Nova pasta de ORIGEM definida: {PASTA_BASE_MANUAL}\n")
                
        elif tipo == "destino":
            print("\n[F2] Abrindo janela de seleção de DESTINO...")
            pasta = filedialog.askdirectory(title="Selecione a Pasta de Destino")
            if pasta:
                with config_lock:
                    PASTA_DESTINO_MANUAL = os.path.normpath(pasta)
                exibir_menu_status()
                print(f"[CONFIG] Nova pasta de DESTINO definida: {PASTA_DESTINO_MANUAL}\n")
                
        elif tipo == "cache":
            print("\n[F3] Abrindo janela de seleção de CACHE...")
            pasta = filedialog.askdirectory(title="Selecione a Nova Pasta do Cache")
            if pasta:
                with config_lock:
                    PASTA_CACHE_GLOBAL = os.path.normpath(pasta)
                exibir_menu_status()
                print(f"[CONFIG] Nova pasta de CACHE definida: {PASTA_CACHE_GLOBAL}\n")
    except Exception as e:
        print(f"[ERRO interface {tipo.upper()}]: {e}")
    finally:
        root.destroy()

class ComandoHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        """Sobrescreve o log padrão do HTTP Server para evitar poluir o console."""
        pass

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def descobrir_caminho_absoluto(self, origem_relativa, pasta_base, path_parts):
        """Calcula de forma precisa a localização física combinando a raiz e o caminho do navegador."""
        raiz = os.path.normpath(pasta_base if pasta_base else os.getcwd())
        
        if path_parts:
            nome_pasta_raiz = os.path.basename(raiz)
            if path_parts[0] == nome_pasta_raiz:
                partes_filtradas = path_parts[1:]
            else:
                partes_filtradas = path_parts
                
            caminho_montado = os.path.join(raiz, *partes_filtradas)
            return os.path.normpath(caminho_montado)
            
        return os.path.normpath(os.path.join(raiz, origem_relativa))

    def do_GET(self):
        if self.path.startswith('/obter_thumb'):
            query = parse_qs(urlparse(self.path).query)
            arquivo_param = query.get('arquivo', [None])[0]
            
            if arquivo_param:
                nome_original = os.path.basename(arquivo_param)
                nome_thumb = os.path.splitext(nome_original)[0] + "_thumb.png"
                
                with config_lock:
                    pasta_cache = PASTA_CACHE_GLOBAL
                caminho_thumb_file = os.path.join(pasta_cache, '.cache_midias', nome_thumb)
                
                if os.path.exists(caminho_thumb_file):
                    try:
                        with open(caminho_thumb_file, 'r', encoding='utf-8', errors='replace') as f:
                            base64_texto = f.read()
                        self.send_response(200)
                        self.send_header('Content-Type', 'text/plain')
                        self.end_headers()
                        self.wfile.write(base64_texto.encode('utf-8', errors='replace'))
                        return
                    except:
                        pass
            self.send_response(404)
            self.end_headers()
            return

    def do_POST(self):
        global PASTA_BASE_MANUAL, PASTA_DESTINO_MANUAL, PASTA_CACHE_GLOBAL
        resposta = {"status": "erro", "mensagem": "Erro interno."}
        status_code = 400
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                post_data = self.rfile.read(content_length)
                dados_texto = post_data.decode('utf-8', errors='replace')
                dados = json.loads(dados_texto)
                
                acao = dados.get('acao')
                origem = dados.get('origem')
                path_parts = dados.get('path_parts', [])
                
                with config_lock:
                    pasta_base = PASTA_BASE_MANUAL
                    pasta_destino_manual = PASTA_DESTINO_MANUAL
                    pasta_cache = PASTA_CACHE_GLOBAL

                if origem:
                    caminho_real_origem = self.descobrir_caminho_absoluto(origem, pasta_base, path_parts)
                    nome_original = os.path.basename(caminho_real_origem)
                    nome_thumb = os.path.splitext(nome_original)[0] + "_thumb.png"
                    caminho_thumb_file = os.path.join(pasta_cache, '.cache_midias', nome_thumb)

                    if acao == 'salvar_cache_thumb':
                        thumb_b64 = dados.get('thumb_b64')
                        if thumb_b64:
                            os.makedirs(os.path.dirname(caminho_thumb_file), exist_ok=True)
                            with open(caminho_thumb_file, 'w', encoding='utf-8', errors='replace') as f:
                                f.write(thumb_b64)
                            status_code = 200
                            resposta = {"status": "sucesso"}

                    elif acao == 'mover':
                        if os.path.exists(caminho_real_origem):
                            if os.path.exists(caminho_thumb_file):
                                try: os.remove(caminho_thumb_file)
                                except: pass
                            
                            pasta_destino = pasta_destino_manual if pasta_destino_manual else os.path.join(os.path.dirname(caminho_real_origem), 'movidos')
                            os.makedirs(pasta_destino, exist_ok=True)
                            destino_final = os.path.join(pasta_destino, nome_original)
                            
                            if os.path.exists(destino_final):
                                base, ext = os.path.splitext(nome_original)
                                c = 1
                                while os.path.exists(os.path.join(pasta_destino, f"{base}_{c}{ext}")): c += 1
                                destino_final = os.path.join(pasta_destino, f"{base}_{c}{ext}")
                                
                            shutil.move(caminho_real_origem, destino_final)
                            
                            # Limpa e atualiza o painel ao mover com sucesso
                            exibir_menu_status()
                            print(f"[SUCESSO] Movido com êxito para: {destino_final}")
                            status_code = 200
                            resposta = {"status": "sucesso"}
                        else:
                            status_code = 404
                            resposta = {"status": "erro", "mensagem": f"Arquivo nao encontrado em: {caminho_real_origem}"}
                            exibir_menu_status()
                            print(f"[ERRO 404] Arquivo ausente no disco físico: {caminho_real_origem}")
        except Exception as e:
            status_code = 500
            resposta = {"status": "erro", "mensagem": str(e)}
            print(f"[ERRO TRATADO]: {str(e)}")
            
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(resposta, ensure_ascii=False).encode('utf-8', errors='replace'))

def rodar_servidor():
    server = HTTPServer(('127.0.0.1', 8080), ComandoHandler)
    try:
        server.serve_forever()
    except Exception as e:
        print(f"[ERRO SERVIDOR]: {e}")
    finally:
        server.server_close()

if __name__ == '__main__':
    keyboard.add_hotkey('f1', lambda: disparar_selecao('origem'))
    keyboard.add_hotkey('f2', lambda: disparar_selecao('destino'))
    keyboard.add_hotkey('f3', lambda: disparar_selecao('cache'))
    
    # Exibe o painel inicial limpo
    exibir_menu_status()
    
    server_thread = threading.Thread(target=rodar_servidor, daemon=True)
    server_thread.start()
    
    try:
        while True:
            try:
                tipo_solicitacao = interface_queue.get(timeout=0.1)
                processar_selecao_pasta(tipo_solicitacao)
                interface_queue.task_done()
            except queue.Empty:
                continue
    except KeyboardInterrupt:
        print("\n[Desligando] Servidor encerrado pelo usuário.")