@echo off
title Iniciando o Servidor Python
echo Instalando dependencias caso nao existam...
pip install keyboard

echo.
echo Iniciando o Server.py...
python "%~dp0Server_02.py"
pause