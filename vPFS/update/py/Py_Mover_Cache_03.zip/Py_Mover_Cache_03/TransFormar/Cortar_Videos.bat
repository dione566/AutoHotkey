@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

:: --- CONFIGURAÇÃO DOS CAMINHOS ---
set "FFMPEG_DIR=C:\Users\user\Downloads\Conversor_Profissional\ffmpeg-2026-02-04-git-627da1111c-essentials_build\bin"
set "FFMPEG_PATH=%FFMPEG_DIR%\ffmpeg.exe"
set "FFPROBE_PATH=%FFMPEG_DIR%\ffprobe.exe"

:inicio
cls
echo ===================================================
echo               CORTE RÁPIDO DE VÍDEO
echo ===================================================
echo.
echo [1] Selecionar um vídeo para cortar
echo [2] Fechar o programa
echo.
set /p "OPCAO=Escolha uma opção (1 ou 2): "

if "%OPCAO%"=="2" goto fim
if "%OPCAO%" neq "1" (
    echo Opção inválida!
    timeout /t 2 > nul
    goto inicio
)

cls
echo ===================================================
echo   1. SELECIONE O VÍDEO NA JANELA QUE ABRIU
echo ===================================================
echo.

:: Janela para selecionar o arquivo
set "dialog=Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.OpenFileDialog; $f.Filter = 'Vídeos (*.mp4;*.mkv;*.avi;*.mov)|*.mp4;*.mkv;*.avi;*.mov|Todos os arquivos (*.*)|*.*'; $f.ShowDialog() | Out-Null; $f.FileName"
for /f "delims=" %%I in ('powershell -Command "%dialog%"') do set "VIDEO_ORIGINAL=%%I"

if "%VIDEO_ORIGINAL%"=="" (
    echo [AVISO] Nenhum arquivo foi selecionado. Voltando ao menu...
    timeout /t 3 > nul
    goto inicio
)

:: Pega a duração total do vídeo usando o ffprobe
for /f "tokens=*" %%A in ('"%FFPROBE_PATH%" -v error -show_entries format^=duration -of default^=noprint_wrappers^=1:nokey^=1 "%VIDEO_ORIGINAL%"') do set "DURACAO_TOTAL=%%A"

echo Vídeo selecionado: "%VIDEO_ORIGINAL%"
echo.
echo ===================================================
echo   2. DEFINA OS CORTES (Exemplos: 30 ou 1:30 ou 02:15)
echo ===================================================
echo.

set /p "CORTAR_INICIO=Quanto deseja remover do INÍCIO? (Se nenhum, digite 0): "
set /p "CORTAR_FIM=Quanto deseja remover do FINAL? (Se nenhum, digite 0): "

:: Define caminhos e nomes de arquivo
for %%F in ("%VIDEO_ORIGINAL%") do (
    set "PASTA=%%~dpF"
    set "NOME=%%~nF"
    set "EXT=%%~xF"
)
set "VIDEO_FINAL=%PASTA%%NOME%_editado%EXT%"

echo.
echo Processando... por favor, aguarde.
echo.

:: Lógica de corte
if "%CORTAR_FIM%" neq "0" (
    :: PowerShell converte o tempo digitado do final (seja MM:SS ou segundos) em segundos puros para a matemática
    for /f "tokens=*" %%C in ('powershell -Command "$ts = New-TimeSpan; if ('%CORTAR_FIM%' -match ':') { $parts = '%CORTAR_FIM%'.Split(':'); if ($parts.Length -eq 2) { $segundos = [int]$parts[0]*60 + [int]$parts[1] } else { $segundos = [int]$parts[0]*3600 + [int]$parts[1]*60 + [int]$parts[2] } } else { $segundos = [double]'%CORTAR_FIM%' }; [math]::Round(%DURACAO_TOTAL% - $segundos, 2)"') do set "TEMPO_FIM=%%C"
    
    "%FFMPEG_PATH%" -ss %CORTAR_INICIO% -to !TEMPO_FIM! -i "%VIDEO_ORIGINAL%" -c copy "%VIDEO_FINAL%" -y
) else (
    "%FFMPEG_PATH%" -ss %CORTAR_INICIO% -i "%VIDEO_ORIGINAL%" -c copy "%VIDEO_FINAL%" -y
)

if %errorlevel% equ 0 (
    echo.
    echo ===================================================
    echo   [SUCESSO] Vídeo gerado com sucesso!
    echo   Salvo em: "%VIDEO_FINAL%"
    echo ===================================================
) else (
    echo.
    echo [ERRO] Ocorreu um problema ao tentar cortar o vídeo.
)

echo.
echo Pressione qualquer tecla para voltar ao início...
pause > nul
goto inicio

:fim
echo Encerrando o programa...
timeout /t 2 > nul
exit