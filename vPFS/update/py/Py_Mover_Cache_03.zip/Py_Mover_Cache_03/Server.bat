@off
python Server.py
pause