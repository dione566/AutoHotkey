from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import shutil
import os
import json

class ComandoHandler(BaseHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_POST(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        dados = json.loads(post_data.decode('utf-8'))
        
        if dados.get('acao') == 'mover':
            origem = dados.get('origem')
            
            # Normaliza o caminho vindo do navegador para o padrão do Windows
            origem_normalizada = os.path.normpath(origem)
            
            # Se o caminho for relativo, vincula ao diretório atual onde o script roda
            if not os.path.isabs(origem_normalizada):
                diretorio_atual = os.getcwd()
                pasta_base_nome = os.path.basename(diretorio_atual)
                if origem_normalizada.startswith(pasta_base_nome):
                    partes = origem_normalizada.split(os.sep)
                    origem_final = os.path.join(diretorio_atual, *partes[1:])
                else:
                    origem_final = os.path.join(diretorio_atual, origem_normalizada)
            else:
                origem_final = origem_normalizada

            try:
                if os.path.exists(origem_final):
                    # 1. Descobre a pasta onde o arquivo original está localizado
                    pasta_do_arquivo = os.path.dirname(origem_final)
                    nome_do_arquivo = os.path.basename(origem_final)
                    
                    # 2. Define o destino estritamente dentro de uma subpasta "movidos" naquele mesmo local
                    pasta_movidos = os.path.join(pasta_do_arquivo, 'movidos')
                    destino_final = os.path.join(pasta_movidos, nome_do_arquivo)
                    
                    # 3. Cria a pasta "movidos" se ela ainda não existir
                    os.makedirs(pasta_movidos, exist_ok=True)
                    
                    # 4. Move o arquivo real
                    shutil.move(origem_final, destino_final)
                    
                    resposta = {"status": "sucesso", "mensagem": "Arquivo movido para a pasta movidos!"}
                    print(f"[SUCESSO] Movido para subpasta: {origem_final} -> {destino_final}")
                else:
                    resposta = {"status": "erro", "mensagem": f"Arquivo nao encontrado em: {origem_final}"}
                    print(f"[ERRO] Arquivo nao encontrado em: {origem_final}")
            except Exception as e:
                resposta = {"status": "erro", "mensagem": str(e)}
                print(f"[ERRO FALHA]: {str(e)}")
                
            self.wfile.write(json.dumps(resposta).encode('utf-8'))

if __name__ == '__main__':
    server = HTTPServer(('127.0.0.1', 8080), ComandoHandler)
    print("Servidor de comandos ativo na porta 8080...")
    server.serve_forever()