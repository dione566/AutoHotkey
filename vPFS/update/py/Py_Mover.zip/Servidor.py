from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import shutil
import os
import json
import threading
import keyboard
import tkinter as tk
from tkinter import filedialog

# Variáveis globais para armazenar as pastas definidas manualmente
PASTA_BASE_MANUAL = ""
PASTA_DESTINO_MANUAL = ""  # Nova variável para o F2

def escutar_f1():
    """Monitora a tecla F1 em segundo plano e abre a seleção de pasta de origem."""
    global PASTA_BASE_MANUAL
    print("[INFO] Monitor de F1 ativo. Pressione F1 para definir a pasta de ORIGEM.")
    
    while True:
        keyboard.wait('f1')
        print("\n[F1] Tecla detectada! Abrindo janela de seleção de ORIGEM...")
        
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        
        pasta_selecionada = filedialog.askdirectory(title="Selecione a nova Pasta de Origem")
        root.destroy()
        
        if pasta_selecionada:
            PASTA_BASE_MANUAL = os.path.normpath(pasta_selecionada)
            print(f"[CONFIG] Nova pasta de ORIGEM definida: {PASTA_BASE_MANUAL}\n")
        else:
            print("[CONFIG] Seleção de origem cancelada.\n")

def escutar_f2():
    """Monitora a tecla F2 em segundo plano e abre a seleção de pasta de destino."""
    global PASTA_DESTINO_MANUAL
    print("[INFO] Monitor de F2 ativo. Pressione F2 para definir a pasta de DESTINO.")
    
    while True:
        keyboard.wait('f2')
        print("\n[F2] Tecla detectada! Abrindo janela de seleção de DESTINO...")
        
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        
        pasta_selecionada = filedialog.askdirectory(title="Selecione a Pasta de Destino para onde mover")
        root.destroy()
        
        if pasta_selecionada:
            PASTA_DESTINO_MANUAL = os.path.normpath(pasta_selecionada)
            print(f"[CONFIG] Nova pasta de DESTINO definida: {PASTA_DESTINO_MANUAL}\n")
        else:
            print("[CONFIG] Seleção de destino cancelada.\n")

class ComandoHandler(BaseHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_POST(self):
        global PASTA_BASE_MANUAL, PASTA_DESTINO_MANUAL
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        dados = json.loads(post_data.decode('utf-8'))
        
        if dados.get('acao') == 'mover':
            origem = dados.get('origem')
            origem_normalizada = os.path.normpath(origem)
            
            # --- LÓGICA DE DEFINIÇÃO DA ORIGEM ---
            if PASTA_BASE_MANUAL:
                nome_base_manual = os.path.basename(PASTA_BASE_MANUAL)
                partes = origem_normalizada.split(os.sep)
                
                if partes[0] == nome_base_manual:
                    origem_final = os.path.join(PASTA_BASE_MANUAL, *partes[1:])
                else:
                    origem_final = os.path.join(PASTA_BASE_MANUAL, origem_normalizada)
            else:
                if not os.path.isabs(origem_normalizada):
                    diretorio_atual = os.getcwd()
                    pasta_base_nome = os.path.basename(diretorio_atual)
                    if origem_normalizada.startswith(pasta_base_nome):
                        partes = origem_normalizada.split(os.sep)
                        origem_final = os.path.join(diretorio_atual, *partes[1:])
                    else:
                        origem_final = os.path.join(diretorio_atual, origem_normalizada)
                else:
                    origem_final = os.path.join(origem_normalizada)

            # --- LÓGICA DE DEFINIÇÃO DO DESTINO (F2) ---
            try:
                if os.path.exists(origem_final):
                    nome_do_arquivo = os.path.basename(origem_final)
                    
                    if PASTA_DESTINO_MANUAL:
                        # Se o F2 foi configurado, usa a pasta escolhida por você
                        pasta_destino = PASTA_DESTINO_MANUAL
                    else:
                        # Comportamento antigo: cria a subpasta 'movidos' junto ao arquivo original
                        pasta_do_arquivo = os.path.dirname(origem_final)
                        pasta_destino = os.path.join(pasta_do_arquivo, 'movidos')
                    
                    destino_final = os.path.join(pasta_destino, nome_do_arquivo)
                    
                    # Garante que a pasta de destino exista
                    os.makedirs(pasta_destino, exist_ok=True)
                    
                    # Move o arquivo
                    shutil.move(origem_final, destino_final)
                    
                    resposta = {"status": "sucesso", "mensagem": f"Arquivo movido para {pasta_destino}"}
                    print(f"[SUCESSO] Movido: {origem_final} -> {destino_final}")
                else:
                    resposta = {"status": "erro", "mensagem": f"Arquivo nao encontrado em: {origem_final}"}
                    print(f"[ERRO] Arquivo nao encontrado em: {origem_final}")
            except Exception as e:
                resposta = {"status": "erro", "mensagem": str(e)}
                print(f"[ERRO FALHA]: {str(e)}")
                
            self.wfile.write(json.dumps(resposta).encode('utf-8'))

if __name__ == '__main__':
    # Inicializa o monitor do F1
    thread_f1 = threading.Thread(target=escutar_f1, daemon=True)
    thread_f1.start()

    # Inicializa o monitor do F2
    thread_f2 = threading.Thread(target=escutar_f2, daemon=True)
    thread_f2.start()

    # Inicializa o servidor HTTP principal
    server = HTTPServer(('127.0.0.1', 8080), ComandoHandler)
    print("Servidor de comandos ativo na porta 8080...")
    server.serve_forever()