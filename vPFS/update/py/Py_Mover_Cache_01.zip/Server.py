from http.server import BaseHTTPRequestHandler, HTTPServer
import os
import json
import shutil
import threading
import keyboard
import tkinter as tk
from tkinter import filedialog
from urllib.parse import urlparse, parse_qs

# Lock para garantir thread-safety ao ler/escrever as pastas globais
config_lock = threading.Lock()
PASTA_BASE_MANUAL = ""
PASTA_DESTINO_MANUAL = ""

# CAMINHO ABSOLUTO FIXO PARA O CACHE DE ÍCONES
PASTA_CACHE_GLOBAL = r"E:\gts\Google_Cache"

def selecionar_pasta_origem():
    """Abre a janela de seleção para a pasta de ORIGEM (Disparado por F1)."""
    global PASTA_BASE_MANUAL
    print("\n[F1] Tecla detectada! Abrindo janela de seleção de ORIGEM...")
    try:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        pasta_selecionada = filedialog.askdirectory(title="Selecione a nova Pasta de Origem")
        root.destroy()
        if pasta_selecionada:
            with config_lock:
                PASTA_BASE_MANUAL = os.path.normpath(pasta_selecionada)
            print(f"[CONFIG] Nova pasta de ORIGEM definida: {PASTA_BASE_MANUAL}\n")
    except Exception as e:
        print(f"[ERRO interface F1]: {e}")

def selecionar_pasta_destino():
    """Abre a janela de seleção para a pasta de DESTINO (Disparado por F2)."""
    global PASTA_DESTINO_MANUAL
    print("\n[F2] Tecla detectada! Abrindo janela de seleção de DESTINO...")
    try:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        pasta_selecionada = filedialog.askdirectory(title="Selecione a Pasta de Destino")
        root.destroy()
        if pasta_selecionada:
            with config_lock:
                PASTA_DESTINO_MANUAL = os.path.normpath(pasta_selecionada)
            print(f"[CONFIG] Nova pasta de DESTINO definida: {PASTA_DESTINO_MANUAL}\n")
    except Exception as e:
        print(f"[ERRO interface F2]: {e}")

class ComandoHandler(BaseHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def descobrir_caminho_absoluto(self, origem_relativa, pasta_base, path_parts):
        origem_normalizada = os.path.normpath(origem_relativa)
        if pasta_base:
            # Se o primeiro nível da pasta arrastada não bater com o nome da pasta selecionada
            # (comum em backups), nós ignoramos o topo e juntamos o resto na pasta_base
            nome_base_manual = os.path.basename(pasta_base)
            if path_parts and path_parts[0] != nome_base_manual:
                # Se for uma pasta de backup estruturada, une mantendo a árvore interna
                if len(path_parts) > 1:
                    return os.path.join(pasta_base, *path_parts[1:])
            
            if path_parts and path_parts[0] == nome_base_manual:
                return os.path.join(pasta_base, *path_parts[1:])
            return os.path.join(pasta_base, origem_normalizada)
        
        diretorio_atual = os.getcwd()
        nome_diretorio_atual = os.path.basename(diretorio_atual)
        if path_parts and path_parts[0] == nome_diretorio_atual:
            return os.path.join(diretorio_atual, *path_parts[1:])
        return os.path.abspath(origem_normalizada)

    def do_GET(self):
        """Retorna a string Base64 salva no HD diretamente como texto plano."""
        if self.path.startswith('/obter_thumb'):
            query = parse_qs(urlparse(self.path).query)
            arquivo_param = query.get('arquivo', [None])[0]
            
            if arquivo_param:
                nome_original = os.path.basename(arquivo_param)
                nome_thumb = os.path.splitext(nome_original)[0] + "_thumb.png"
                caminho_thumb_file = os.path.join(PASTA_CACHE_GLOBAL, '.cache_midias', nome_thumb)
                
                if os.path.exists(caminho_thumb_file):
                    try:
                        with open(caminho_thumb_file, 'r', encoding='utf-8', errors='replace') as f:
                            base64_texto = f.read()
                        self.send_response(200)
                        self.send_header('Content-Type', 'text/plain')
                        self.end_headers()
                        self.wfile.write(base64_texto.encode('utf-8', errors='replace'))
                        return
                    except:
                        pass
            self.send_response(404)
            self.end_headers()
            return

    def do_POST(self):
        global PASTA_BASE_MANUAL, PASTA_DESTINO_MANUAL
        resposta = {"status": "erro", "mensagem": "Erro interno."}
        status_code = 400
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                post_data = self.rfile.read(content_length)
                dados_texto = post_data.decode('utf-8', errors='replace')
                dados = json.loads(dados_texto)
                
                acao = dados.get('acao')
                origem = dados.get('origem')
                path_parts = dados.get('path_parts', [])
                
                with config_lock:
                    pasta_base = PASTA_BASE_MANUAL
                    pasta_destino_manual = PASTA_DESTINO_MANUAL

                if origem:
                    caminho_real_origem = self.descobrir_caminho_absoluto(origem, pasta_base, path_parts)
                    nome_original = os.path.basename(caminho_real_origem)
                    nome_thumb = os.path.splitext(nome_original)[0] + "_thumb.png"
                    caminho_thumb_file = os.path.join(PASTA_CACHE_GLOBAL, '.cache_midias', nome_thumb)

                    # --- AÇÃO: SALVAR TEXTO BASE64 NO HD ---
                    if acao == 'salvar_cache_thumb':
                        thumb_b64 = dados.get('thumb_b64')
                        if thumb_b64:
                            os.makedirs(os.path.dirname(caminho_thumb_file), exist_ok=True)
                            with open(caminho_thumb_file, 'w', encoding='utf-8', errors='replace') as f:
                                f.write(thumb_b64)
                            status_code = 200
                            resposta = {"status": "sucesso"}

                    # --- AÇÃO: MOVER ---
                    elif acao == 'mover':
                        if os.path.exists(caminho_real_origem):
                            if os.path.exists(caminho_thumb_file):
                                try: os.remove(caminho_thumb_file)
                                except: pass
                            
                            pasta_destino = pasta_destino_manual if pasta_destino_manual else os.path.join(os.path.dirname(caminho_real_origem), 'movidos')
                            os.makedirs(pasta_destino, exist_ok=True)
                            destino_final = os.path.join(pasta_destino, nome_original)
                            
                            if os.path.exists(destino_final):
                                base, ext = os.path.splitext(nome_original)
                                c = 1
                                while os.path.exists(os.path.join(pasta_destino, f"{base}_{c}{ext}")): c += 1
                                destino_final = os.path.join(pasta_destino, f"{base}_{c}{ext}")
                                
                            shutil.move(caminho_real_origem, destino_final)
                            status_code = 200
                            resposta = {"status": "sucesso"}
                        else:
                            status_code = 404
                            resposta = {"status": "erro", "mensagem": f"Arquivo nao encontrado em: {caminho_real_origem}"}
        except Exception as e:
            status_code = 500
            resposta = {"status": "erro", "mensagem": str(e)}
            print(f"[ERRO TRATADO]: {str(e)}")
            
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(resposta, ensure_ascii=False).encode('utf-8', errors='replace'))

if __name__ == '__main__':
    keyboard.add_hotkey('f1', selecionar_pasta_origem)
    keyboard.add_hotkey('f2', selecionar_pasta_destino)
    
    print("=" * 60)
    print(" SERVIDOR DE CACHE BASE64 ATIVO E BLINDADO")
    print(f" URL local: http://127.0.0.1:8080")
    print(f" DIRETÓRIO DE CACHE: {PASTA_CACHE_GLOBAL}")
    print("=" * 60)
    print(" ATALHOS DETECTÁVEIS NO TECLADO:")
    print(" [F1] -> Escolher/Mudar a Pasta de Origem dos Arquivos")
    print(" [F2] -> Escolher/Mudar a Pasta de Destino para onde os Arquivos vão")
    print("-" * 60)
    print(" Aguardando comandos ou ativação de teclas...")
    
    server = HTTPServer(('127.0.0.1', 8080), ComandoHandler)
    try: 
        server.serve_forever()
    except KeyboardInterrupt: 
        server.server_close()